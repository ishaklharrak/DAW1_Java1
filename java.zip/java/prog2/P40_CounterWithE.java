package main.java.prog2;

/**
 * <b>Content</b> flow control, for nested loops
 * <hr/>
 * <br/>
 * <img src="../../../../javadoc/resources/P40_CounterWithE.png">
 */
public class P40_CounterWithE {

    public static void main(String[] args) {
        // Write your program here
        
    }
}
