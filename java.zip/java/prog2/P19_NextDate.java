package main.java.prog2;

import java.util.Scanner;

/**
 * <b>Content</b>: flow control, date logic (fixed 30-day months)<br/>
 * <img src="../../../../javadoc/resources/P19_NextDate.png"/>
 */
public class P19_NextDate {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Write your program here
       
    }
}
