package main.java.prog2;

/**
 * <b>Content</b> flow control, for nested loops
 * <hr/>
 * <br/>
 * <img src="../../../../javadoc/resources/P37_MultiplicationTables.png">
 */
public class P37_MultiplicationTables {

    public static void main(String[] args) {
         // Write your program here
        
    }
}
