package main.java.prog2;

import java.util.Scanner;

/**
 * <b>Content</b> flow control, conditional, time logic <hr/><br/>
 * <img src="../../../../javadoc/resources/P17_NextSecond.png">
 */
public class P17_NextSecond {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Write your program here
        
    }
}
