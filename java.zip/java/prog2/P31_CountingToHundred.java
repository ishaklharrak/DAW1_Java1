package main.java.prog2;

import java.util.Scanner;

/**
 * <b>Content</b> flow control, for loops <hr/><br/>
 * <img src="../../../../javadoc/resources/P31_CountingToHundred.png">
 */
public class P31_CountingToHundred {

    public static void main(String[] args) {
    	Scanner scanner = new Scanner(System.in);        

        // Write your program here
        
    }
}
