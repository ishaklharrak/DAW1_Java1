package main.java.prog2;

import java.util.Scanner;

/**
 * <b>Content</b> array, searching values
 * <hr/>
 * <br/>
 * <img src="../../../../javadoc/resources/P46_IndexWasNotFound.png">
 */
public class P46_IndexWasNotFound {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] array = new int[10];
        array[0] = 6;
        array[1] = 2;
        array[2] = 8;
        array[3] = 1;
        array[4] = 3;
        array[5] = 0;
        array[6] = 9;
        array[7] = 7;

        System.out.print("Search for? ");
        int searching = scanner.nextInt();
        scanner.nextLine();

        // Write your program here
        // Implement the search functionality here
        
    }

}
