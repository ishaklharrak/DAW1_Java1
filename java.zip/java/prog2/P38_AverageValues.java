package main.java.prog2;

import java.util.Scanner;

/**
 * <b>Content</b> flow control, for nested loops
 * <hr/>
 * <br/>
 * <img src="../../../../javadoc/resources/P38_AverageValues.png">
 */
public class P38_AverageValues {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int students = 3;
        int subjects = 4;

        // Write your program here
        
    }
}
