package main.java.prog2;

import java.time.Year;
import java.util.Scanner;

/**
 * <b>Content</b> flow control, date logic with Year class <hr/><br/>
 * <img src="../../../../javadoc/resources/P20_AccurateNextDate.png">
 */
public class P20_AccurateNextDate {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Write your program here
        
    }    
}
