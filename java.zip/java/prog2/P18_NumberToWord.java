package main.java.prog2;

import java.util.Scanner;

/**
 * <b>Content</b> flow control, switch statement <hr/><br/>
 * <img src="../../../../javadoc/resources/P18_NumberToWord.png">
 */
public class P18_NumberToWord {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Write your program here
        
    }
}
