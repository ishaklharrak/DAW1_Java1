package main.java.prog2;

import java.util.Scanner;

/**
 * <b>Content</b> flow control, for nested loops
 * <hr/>
 * <br/>
 * <img src="../../../../javadoc/resources/P39_BurguerChain.png">
 */
public class P39_BurguerChain {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int restaurants = 3;
        int days = 7;

        System.out.println("Weekly Burger Sales Report");
        System.out.println();

        // Write your program here
        
    }
}
