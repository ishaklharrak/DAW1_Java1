package main.java.prog2;

import java.util.Scanner;

/**
 * <b>Content</b> array, get and set values
 * <hr/>
 * <br/>
 * <img src="../../../../javadoc/resources/P44_CheckOrder.png">
 */
public class P44_CheckOrder {

    public static void main(String[] args) {
        // Write your program here
        
    }
}
