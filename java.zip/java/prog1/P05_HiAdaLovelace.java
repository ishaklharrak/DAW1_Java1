package main.java.prog1;

/**
 * <div class="block">
 *   <strong>Concatenation</strong><br/>
 *   Program to join data <br/>
 *   <img src="../../../../javadoc/resources/P05_HiAdaLovelace.png"/>
 * </div>
 */
public class P05_HiAdaLovelace {

    public static void main(String[] args) {
    	// Declares a String variable named 'name' and assigns it the value "Ada Lovelace"
        String name = "Ada Lovelace";
        
        // Write your program here
        System.out.println("Hi " + name + "!");
    }
}
