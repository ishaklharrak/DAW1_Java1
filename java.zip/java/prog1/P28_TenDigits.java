package main.java.prog1;

import java.util.Scanner;

/**
 * <div class="block">
 *   <strong>Operators</strong><br/>
 *   Program to calculate data<br/>
 *   <img src="../../../../javadoc/resources/P28_TenDigits.png"/>
 * </div>
 */
public class P28_TenDigits {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Write your program here
        // Read input
        int N = scanner.nextInt();
        // Extract tens digit
        int tensDigit = (N / 10) % 10;
        // Print result
        System.out.println(tensDigit);

        scanner.close();
    }
}
