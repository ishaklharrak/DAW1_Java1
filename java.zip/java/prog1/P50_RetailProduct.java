package main.java.prog1;

import java.util.Locale;

public class P50_RetailProduct {
public static void main(String[] args) {
// Variables en español
double costeProducto = 60.00;
double porcentajeBeneficio = 0.224; // 22.4% para que el precio final sea 73.44

    // Cálculos
    double precioVentaFinal = costeProducto * (1 + porcentajeBeneficio);
    double beneficioNeto = precioVentaFinal - costeProducto;
    double margenBeneficio = (beneficioNeto / precioVentaFinal) * 100;

    // Salida con formato de dos decimales y punto decimal
    System.out.println(String.format(Locale.US, "Final selling price: $%.2f", precioVentaFinal));
    System.out.println(String.format(Locale.US, "Total cost price: $%.2f", costeProducto));
    System.out.println(String.format(Locale.US, "Net profit: $%.2f", beneficioNeto));
    System.out.println(String.format(Locale.US, "Profit margin: %.2f%%", margenBeneficio));
}

}

