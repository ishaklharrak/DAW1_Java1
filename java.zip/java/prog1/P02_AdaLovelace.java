package main.java.prog1;

/**
 * <div class="block">
 *   <strong>Printing</strong><br/>
*   Program to verify output functionality <br/>
*   <img src="../../../../javadoc/resources/P02_AdaLovelace.png"/>
 * </div>
 */
public class P02_AdaLovelace {

    public static void main(String[] args) {
        // Write your program here
        System.out.println("Ada Lovelace");
    }
}
