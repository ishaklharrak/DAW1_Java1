package main.java.prog1;

import java.util.Scanner;

public class P48_YearlySavings {

    public static void main(String[] args) {
// Variables en español
        double ingresosMensuales = 4200.0;
        double bonoTrimestral = 1500.0;
        double costoCoworking = 250.0;
        double costoSuscripcion = 300.0;
        double porcentajeImpuesto = 0.18;
        int meses = 12;
        int trimestres = 4;

        // Cálculos
        double ingresoBruto = ingresosMensuales * meses + bonoTrimestral * trimestres;
        double gastosMensuales = costoCoworking + costoSuscripcion;
        double totalGastos = gastosMensuales * meses;
        double netoAntesImpuesto = ingresoBruto - totalGastos;
        double gananciasFinales = netoAntesImpuesto * (1 - porcentajeImpuesto);

        // Redondeo a enteros para que coincida con el test
        System.out.println("Gross income: " + Math.round(ingresoBruto) + "$");
        System.out.println("Net income before tax: " + Math.round(netoAntesImpuesto) + "$");
        System.out.println("Final earnings after tax: " + Math.round(gananciasFinales) + "$");
    }

}
