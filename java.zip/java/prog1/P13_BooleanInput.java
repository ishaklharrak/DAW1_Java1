package main.java.prog1;

import java.util.Scanner;

/**
 * <div class="block">
 *   <strong>Reading booleans</strong><br/>
 *   Program to input boolean as a part of output <br/>
 *   <img src="../../../../javadoc/resources/P13_BooleanInput.png"/>
 * </div>
 */
public class P13_BooleanInput {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Write your program here
        System.out.println("Write something:");
        String word = scanner.nextLine();
        
        
        if (Boolean.parseBoolean(word) == false) {
            System.out.println("True or false? false");
        }
        
        else if (Boolean.parseBoolean(word) == true) {
            System.out.println("True or false? true");
        }
        
        else{
            System.out.println("True or false? false");
        }
    }
    
}
