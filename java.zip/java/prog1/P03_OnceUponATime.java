package main.java.prog1;

/**
 * <div class="block">
 *   <strong>Printing</strong><br/>
 *   Program to printing multiple lines <br/>
 *   <img src="../../../../javadoc/resources/P03_OnceUponATime.png"/>
 * </div>
 */
public class P03_OnceUponATime {

    public static void main(String[] args) {
    	// Write your program here
        System.out.println("Once upon a time");
        System.out.println("there was");
        System.out.println("a program");
    }
}
