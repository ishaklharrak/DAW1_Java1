package main.java.prog1;

import java.util.Random;

public class P45_WeeklySales {

    public static void main(String[] args) {
        Random random = new Random();
        int total = 0;

        for (int dia = 1; dia <= 7; dia++) {
            int ventas = 50 + random.nextInt(151); // 50..200
            System.out.println("Day " + dia + ": $" + ventas);
            total += ventas;
        }

        System.out.println("Total sales this week(7 days): $" + total);
    }
}
