package main.java.prog1;

import java.util.Scanner;

/**
 * <div class="block">
 *   <strong>Operators</strong><br/>
 *   Program to calculate data <br/>
 *   <img src="../../../../javadoc/resources/P20_DivisionFormula.png"/>
 * </div>
 */
public class P20_DivisionFormula {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Write your program here
              //input
        System.out.println("Give the first number:");
        int num1 = scanner.nextInt();
        System.out.println("Give the second number:");
        int num2 = scanner.nextInt();
        //logic
        int div = num1 / num2;
        //output
        System.out.println(num1 + " / " + num2 + " = " + div);

    }
}
