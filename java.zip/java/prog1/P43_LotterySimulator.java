package main.java.prog1;

import java.util.Random;
import java.util.Set;
import java.util.HashSet;

/**
 * <div class="block">
 * <strong>Generate random numbers with Random</strong><br/>
 * Program to calculate data<br/>
 * <img src="../../../../javadoc/resources/P43_LotterySimulator.png"/>
 * </div>
 */
public class P43_LotterySimulator {

    public static void main(String[] args) {
        Random random = new Random();

        Set<Integer> numeros = new HashSet<>();

        while (numeros.size() < 6) {
            int numero = random.nextInt(49) + 1; 
            numeros.add(numero);
        }

        System.out.print("Your numbers: ");
        for (int numero : numeros) {
            System.out.print(numero + " ");
        }
    }
}
