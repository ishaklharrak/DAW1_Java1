package main.java.prog1;
import java.util.Scanner;

/**
 * <div class="block">
 *   <strong>Operators</strong><br/>
 *   Program to calculate data<br/>
 *   <img src="../../../../javadoc/resources/P36_IsDriver.png"/>
 * </div>
 */
public class P36_IsDriver {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Write your program here
        int edad = scanner.nextInt();
        
        boolean carnet = scanner.nextBoolean();


        boolean conductor = (edad >= 18) && carnet;

        // Imprimir resultado
        System.out.println(conductor);

        scanner.close();
    }
}
