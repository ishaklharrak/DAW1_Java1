/**
 * Structured Programming I:
 * <ul>
 *   <li>Structures and blocks</li>
 *   <li>Data types</li>
 *   <li>Constants and literals</li>
 *   <li>Operators</li>
 *   <li>Type conversions</li>
 *   <li>Comments</li>
 *   <li>Statements</li>
 *   <li>Flow control</li>
 * </ul>
 */
package main.java.prog1;