package main.java.prog1;
import java.util.Locale;
import java.util.Scanner;

/**
 * <div class="block">
 *   <strong>Operators</strong><br/>
 *   Program to calculate data<br/>
 *   <img src="../../../../javadoc/resources/P34_PriceWithVAT.png"/>
 * </div>
 */
public class P34_PriceWithVAT {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        scanner.useLocale(Locale.US); // dot as decimal separator
        
        // Write your program here
        double precio = scanner.nextDouble();
        double VAT = (precio / 100) * 21;
        double precio1 = precio + VAT;
        System.out.printf(Locale.US, "Total price with VAT: %.2f%n", precio1);
        scanner.close();
    }
}
