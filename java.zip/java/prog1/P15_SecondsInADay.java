package main.java.prog1;

import java.util.Scanner;

/**
 * <div class="block">
 *   <strong>Operators</strong><br/>
 *   Program to calculate data <br/>
 *   <img src="../../../../javadoc/resources/P15_SecondsInADay.png"/>
 * </div>
 */
public class P15_SecondsInADay {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Write your program here
        
        //input
        System.out.println("How many days would you like to convert to seconds?");
        int days = scanner.nextInt();
        //logic
        int seconds = days * 86400;
        //output
        System.out.println(seconds);
        
    }
}
