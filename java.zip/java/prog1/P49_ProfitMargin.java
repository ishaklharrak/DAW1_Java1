package main.java.prog1;

public class P49_ProfitMargin {

    public static void main(String[] args) {
// Variables en español
        double precioOriginal = 60.0;
        double descuento = 0.12;
        double coste = 40.0;

    // Cálculo del precio con descuento
    double precioDescontado = precioOriginal * (1 - descuento);

        // Cálculo del margen de beneficio en porcentaje
        double margenBeneficio = ((precioDescontado - coste) / precioDescontado) * 100;

        // Redondear a 2 decimales para que coincida exactamente con el test
        double margenBeneficioRedondeado = Math.round(margenBeneficio * 100.0) / 100.0;

        // Salida final
        System.out.println("Profit margin: " + margenBeneficioRedondeado + "%");
    }


}
