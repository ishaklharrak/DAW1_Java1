package main.java.prog1;

import java.util.Scanner;

/**
 * <div class="block">
 *   <strong>Operators and Constants</strong><br/>
 *   Program to calculate data<br/>
 *   <img src="../../../../javadoc/resources/P40_DiscountedPrice.png"/>
 * </div>
 */
public class P40_DiscountedPrice {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Write your program here
        
        boolean Lcard = scanner.nextBoolean();
        boolean DiaS = scanner.nextBoolean();
        boolean aprobado = scanner.nextBoolean();

        boolean descuento = aprobado && (Lcard || DiaS);
        
        System.out.println(descuento);
    }
}
