package main.java.prog1;

import java.util.Scanner;

/**
 * <div class="block">
 *   <strong>Operators</strong><br/>
 *   Program to calculate data <br/>
 *   <img src="../../../../javadoc/resources/P22_AverageOfThreeNumbers.png"/>
 * </div>
 */
public class P22_AverageOfThreeNumbers {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Write your program here
        //input
        System.out.println("Give the first number:");
        int num1 = scanner.nextInt();
        System.out.println("Give the second number:");
        int num2 = scanner.nextInt();
        System.out.println("Give the third number:");
        int num3 = scanner.nextInt();
        //logic
        double average = (num1 + num2 + num3) / (double) 3;
        //output
        System.out.println("The average is " + average );
      
    }
}
