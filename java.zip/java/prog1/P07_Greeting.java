package main.java.prog1;

import java.util.Scanner;

/**
 * <div class="block">
 *   <strong>Reading strings</strong><br/>
 *   Program to input string as a part of output <br/>
 *   <img src="../../../../javadoc/resources/P07_Greeting.png"/>
 * </div>
 */
public class P07_Greeting {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Write your program here
                // input
        System.out.println("What's your name?");
        // pedir un mensaje al usuario
        
        // logic
        // nothing
        String nombre = String.valueOf(scanner.nextLine());
        
        // output
        System.out.println("Hi " + nombre);


    }
}
