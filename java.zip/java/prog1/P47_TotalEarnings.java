package main.java.prog1;

import java.util.Locale;

public class P47_TotalEarnings {

    public static void main(String[] args) {
// Variables en español
        double salarioBase = 2500.0;
        double ventas = 40000.0;
        double porcentajeComision = 0.07;
        double bonificacion = 300.0;

        // Cálculos
        double comision = ventas * porcentajeComision;
        double gananciasTotales = salarioBase + comision + bonificacion;

        // Salida formateada
        System.out.printf(Locale.US, "Total earnings: %.2f$", gananciasTotales);
    }

}
