package main.java.prog1;
import java.util.Scanner;

/**
 * <div class="block">
 *   <strong>Operators</strong><br/>
 *   Program to calculate data<br/>
 *   <img src="../../../../javadoc/resources/P35_ShippingCost.png"/>
 * </div>
 */
public class P35_ShippingCost {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int precio = scanner.nextInt();

        boolean envio = precio > 100;

        System.out.println(envio);
    }
}
