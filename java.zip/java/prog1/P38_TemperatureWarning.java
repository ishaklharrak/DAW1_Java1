package main.java.prog1;
import java.util.Scanner;

/**
 * <div class="block">
 *   <strong>Operators and Constants</strong><br/>
 *   Program to calculate data<br/>
 *   <img src="../../../../javadoc/resources/P38_TemperatureWarning.png"/>
 * </div>
 */
public class P38_TemperatureWarning {
	public final static int MIN_TEMPERATURE= 34;
	public final static int MAX_TEMPERATURE= 37;
	
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Write your program here
        int temperatura = scanner.nextInt();

        boolean alerta = (temperatura > 37 || temperatura < 34);
        System.out.println(alerta);
        scanner.close();
    }
}
