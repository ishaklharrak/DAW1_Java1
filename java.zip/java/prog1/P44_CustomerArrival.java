package main.java.prog1;

import java.util.Random;
import java.util.Locale;

/**
 * <div class="block">
 * <strong>Simulate customer arrivals</strong><br/>
 * Program to calculate data<br/>
 * </div>
 */
public class P44_CustomerArrival {

    public static void main(String[] args) {
        Random rand = new Random();
        int previousTime = 0;
        int totalWait = 0;

        for (int i = 1; i <= 5; i++) {
            int wait = rand.nextInt(10) + 1;
            int arrival = previousTime + wait;

            System.out.println("Customer " + i + " arrived at minute: " + arrival);

            previousTime = arrival;
            totalWait += wait;
        }

        double averageWait = (double) totalWait / 5;
        System.out.println("Average waiting time: " + averageWait + " minutes");
    }
}
