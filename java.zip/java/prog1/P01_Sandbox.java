package main.java.prog1;

/**
 * <div class="block">
 *   <strong>Verification Setup</strong><br/>
 *   Initial sandbox for checking environment configuration and toolchain setup.<br/>
 *   <img src="../../../../javadoc/resources/P01_Sandbox.png"/>
 * </div>
 */
public class P01_Sandbox {

    public static void main(String[] args) {
        // Write your program here
    }
}
