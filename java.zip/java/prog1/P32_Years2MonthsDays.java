package main.java.prog1;
import java.util.Scanner;

/**
 * <div class="block">
 *   <strong>Operators</strong><br/>
 *   Program to calculate data<br/>
 *   <img src="../../../../javadoc/resources/P32_Years2MonthsDays.png"/>
 * </div>
 */
public class P32_Years2MonthsDays {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Write your program here
        int year = scanner.nextInt();

        int months = year * 12;
        int days = year * 360;

        System.out.println(year +" years = " + months + " months = " + days + " days");
        scanner.close();
        scanner.close();
    }
}
