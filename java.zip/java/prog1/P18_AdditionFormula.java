package main.java.prog1;

import java.util.Scanner;

/**
 * <div class="block">
 *   <strong>Operators</strong><br/>
 *   Program to calculate data <br/>
 *   <img src="../../../../javadoc/resources/P18_AdditionFormula.png"/>
 * </div>
 */
public class P18_AdditionFormula {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Write your program here
        //input
        System.out.println("Give the first number:");
        int num1 = scanner.nextInt();
        System.out.println("Give the second number:");
        int num2 = scanner.nextInt();
        //logic
        int suma = num1 + num2;
        //output
        System.out.println(num1 + " + " + num2 + " = " + suma);
        
    }
}
