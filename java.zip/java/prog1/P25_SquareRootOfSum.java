package main.java.prog1;

import java.util.Scanner;

/**
 * <div class="block">
 *   <strong>Operators</strong><br/>
 *   Program to calculate data <br/>
 *   <img src="../../../../javadoc/resources/P25_SquareRootOfSum.png"/>
 * </div>
 */
public class P25_SquareRootOfSum {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Write your program here
        //input
        int num1 = scanner.nextInt();
        int num2 = scanner.nextInt();
        //logic
        int suma = num1 + num2;
        double raiz = Math.sqrt(suma);
        //out 
        System.out.println(raiz);
       
    }
}
