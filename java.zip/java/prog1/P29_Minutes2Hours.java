package main.java.prog1;

import java.util.Scanner;

/**
 * <div class="block">
 *   <strong>Operators</strong><br/>
 *   Program to calculate data<br/>
 *   <img src="../../../../javadoc/resources/P29_Minutes2Hours.png"/>
 * </div>
 */
public class P29_Minutes2Hours {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

         // Read input
        int minutos = scanner.nextInt();

        // Convert to hours and minutes
        int hours = minutos / 60;
        int minutes = minutos % 60;

        // Print result
        System.out.println(hours + " hours and " + minutes + " minutes");
        
        scanner.close();
    }
}
