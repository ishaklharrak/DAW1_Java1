package main.java.prog1;

import java.util.Scanner;

/**
 * <div class="block">
 *   <strong>Operators</strong><br/>
 *   Program to calculate data <br/>
 *   <img src="../../../../javadoc/resources/P23_SimpleCalculator.png"/>
 * </div>
 */
public class P23_SimpleCalculator {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Write your program here
        //INPUT
         System.out.println("Give the first number:");
        int num1 = scanner.nextInt();
        System.out.println("Give the second number:");
        int num2 = scanner.nextInt();
        //logica
        int sum = num1 + num2;
        int res = num1 - num2;
        int mult = num1 * num2;
        double divi = num1 / num2;
        //out
        System.out.println(num1 + " + " + num2 + " = " +sum);
        System.out.println(num1 + " - " + num2 + " = " +res);
        System.out.println(num1 + " * " + num2 + " = " +mult);
        System.out.println(num1 + " / " + num2 + " = " +divi);
    }
}
