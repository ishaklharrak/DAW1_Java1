package main.java.prog1;
import java.util.Locale;
import java.util.Scanner;
import java.util.Random;
/**
 * <div class="block">
 *   <strong>Generate random numbers with Math</strong><br/>
 *   Program to calculate data<br/>
 *   <img src="../../../../javadoc/resources/P41_MathDiscount.png"/>
 * </div>
 */
public class P41_MathDiscount {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        scanner.useLocale(Locale.US); // dot as decimal separator
        
        // Write your program here
        double precio = scanner.nextDouble();

        Random rand = new Random();
        double porcentajeD = rand.nextDouble() * 10;

        double precioF = precio * (1 - porcentajeD / 100);

        System.out.printf(Locale.US, "Discount: %.2f%%\n", porcentajeD);
        System.out.printf(Locale.US, "Final price: %.2f\n", precioF);
        scanner.close();
    }

}
