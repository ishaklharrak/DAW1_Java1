package main.java.prog1;

import java.util.Scanner;

/**
 * <div class="block">
 *   <strong>Operators</strong><br/>
 *   Program to calculate data<br/>
 *   <img src="../../../../javadoc/resources/P30_Seconds2Minutes.png"/>
 * </div>
 */
public class P30_Seconds2Minutes {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int segundos = scanner.nextInt();

        // Convert to hours and minutes
        int minutes = segundos / 60;
        int seconds = segundos % 60;

        // Print result
        System.out.println(minutes + " minutes and " + seconds + " seconds");
        
        scanner.close();
    }
}
