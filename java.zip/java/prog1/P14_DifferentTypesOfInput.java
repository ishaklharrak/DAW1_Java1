package main.java.prog1;

import java.util.Locale;
import java.util.Scanner;

public class P14_DifferentTypesOfInput {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.US); // dot as decimal separator

        // Leer un string completo
        System.out.println("Give a string:");
        String cadena = sc.nextLine();

        // Leer un entero
        System.out.println("Give an integer:");
        int entero = sc.nextInt();

        // Leer un double
        System.out.println("Give a double:");
        double decimal = sc.nextDouble();

        // Leer un boolean
        System.out.println("Give a boolean:");
        boolean booleano = sc.nextBoolean();

        // Mostrar los valores leídos
        System.out.println("You gave the string " + cadena);
        System.out.println("You gave the integer " + entero);
        System.out.println("You gave the double " + decimal);
        System.out.println("You gave the boolean " + booleano);
    }

}
