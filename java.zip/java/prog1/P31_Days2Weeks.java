package main.java.prog1;

import java.util.Scanner;

/**
 * <div class="block">
 *   <strong>Operators</strong><br/>
 *   Program to calculate data<br/>
 *   <img src="../../../../javadoc/resources/P31_Days2Weeks.png"/>
 * </div>
 */
public class P31_Days2Weeks {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Write your program here
        int days = scanner.nextInt();

        // Convert to hours and minutes
        int weeks = days / 7;
        int days1 = days % 7;

        // Print result
        System.out.println(weeks + " weeks and " + days1 + " days");
        scanner.close();
    }
}
