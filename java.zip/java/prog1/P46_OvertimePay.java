package main.java.prog1;

/**
 * <div class="block">
 * <strong>Business logic</strong><br/>
 * Program to calculate data<br/>
 * <img src="../../../../javadoc/resources/P46_OvertimePay.png"/>
 * </div>
 */
public class P46_OvertimePay {

    public static final String EURO_SYMBOL = "\u20AC";

    public static void main(String[] args) {

        // Write your program here
        // Datos de ejemplo
        double S_base = 100.0;
        double H_extras = 10;
        double T_extra = 30.0;

        // Cálculos
        double overtimePay = H_extras * T_extra;
        double totalPay = S_base + overtimePay;

        // Salida
        System.out.println("Overtime pay: " + overtimePay + EURO_SYMBOL);
        System.out.println("Total pay including bonus: " + totalPay + EURO_SYMBOL);
    }
}
